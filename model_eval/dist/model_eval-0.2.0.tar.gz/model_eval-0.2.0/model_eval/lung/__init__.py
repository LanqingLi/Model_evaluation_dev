name = 'lung'
from config import *
from evaluator import *
from get_df_nodules import *
from get_df_objects import *
from xml_tools import *