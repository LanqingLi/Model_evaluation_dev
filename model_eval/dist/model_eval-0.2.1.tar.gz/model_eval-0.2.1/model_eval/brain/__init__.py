name = 'brain'
from config import *
from evaluator import *